const DB_NAME = "QuranDB", DB_VERSION = 1;
let db;

function openDB() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = (e) => {
      db = e.target.result;
      if (!db.objectStoreNames.contains("audio")) {
        db.createObjectStore("audio", { keyPath: "id" });
      }
    };
    request.onsuccess = () => {
      db = request.result;
      resolve();
    };
    request.onerror = () => reject(request.error);
  });
}

async function loadSurah() {
  const res = await fetch("surah/001.json");
  const data = await res.json();
  const container = document.getElementById("ayat-container");

  for (let i = 1; i <= data.count; i++) {
    const ayat = data.verses[i.toString()];
    const div = document.createElement("div");
    div.className = "ayat";
    div.innerHTML = `
      <div class="ar">${ayat.ar}</div>
      <div class="id">${ayat.id}</div>
      <button onclick="playAyat('001', ${i})">▶️ Putar Ayat ${i}</button>
    `;
    container.appendChild(div);
  }
}

async function playAyat(surah, ayat) {
  const id = `${surah}_${ayat}`;
  const tx = db.transaction("audio", "readonly");
  const store = tx.objectStore("audio");
  const result = await store.get(id);

  let blob;
  if (result) {
    blob = result.blob;
  } else {
    const meta = await fetch(`audio/${surah}/metadata.json`).then(r => r.json());
    const file = meta.verse[`verse_${ayat}`].file;
    blob = await fetch(`audio/${surah}/${file}`).then(r => r.blob());
    const tx2 = db.transaction("audio", "readwrite");
    tx2.objectStore("audio").put({ id, blob });
  }

  const url = URL.createObjectURL(blob);
  const player = document.getElementById("audio-player");
  player.src = url;
  player.play();
}

openDB().then(loadSurah);
